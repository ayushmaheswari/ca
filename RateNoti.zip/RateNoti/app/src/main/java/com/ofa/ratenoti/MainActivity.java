package com.ofa.ratenoti;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    RatingBar ratingBar;
    NotificationManager nm;
    static final String channelname = "channel";
    static final String notifname = "my notif";
    static final int notifid = 0;
    float ratingf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            toolbar=findViewById(R.id.toolbar);
            ratingBar=findViewById(R.id.ratingbar);
            nm=(NotificationManager)getSystemService(Service.NOTIFICATION_SERVICE);
          notifcationchannel();
            ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

                @Override
                public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                    Toast.makeText(MainActivity.this, ""+rating, Toast.LENGTH_SHORT).show();
                    String s="";
                    //to convert rating to string
                    if(rating>0 && rating<=1.0){
                        s="a";
                    }
                    if(rating>1.0 && rating<=2.0){
                        s="b";
                    }
                    if(rating>2.0 && rating<=3.0){
                        s="c";
                    }
                    if(rating>3.0 && rating<=4.0){
                        s="d";
                    }
                    if(rating>4.0 && rating<=5.0){
                        s="e";

                    }
                        ratingf=rating;
                    createNotif(s);
                }
            });
    }

    public  void createNotif(String st){

        Intent intent = new Intent(MainActivity.this, MyReceiver.class);
        intent.putExtra("rating",ratingf);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(this,notifid,
                intent,PendingIntent.FLAG_CANCEL_CURRENT);//clear all notif before new
        NotificationCompat.Builder builder=new NotificationCompat.Builder(this,channelname);
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        builder.setContentTitle("Rating Notification");
        builder.setSmallIcon(R.drawable.ic_launcher_foreground);
        builder.setContentIntent(pendingIntent);
        builder.setAutoCancel(true);
        //based on rating string provide notif
       switch (st){
           case "a":
               builder.setContentText(" Rating is poor!Sorry! :( :(  "+ratingf);
               break;

           case "b":
               builder.setContentText("Rating is Bad! :( "+ratingf);
               break;

           case "c":
               builder.setContentText(" Rating is Average! :| "+ratingf);
               break;

           case "d":
               builder.setContentText("Rating is good! :) "+ratingf);
               break;

           case "e":
               builder.setContentText("Rating is Excellen!Thank You :) :) "+ratingf);
               break;
               default:
                   builder.setContentText("No Rating Provided ");
       }
        nm.notify(notifid,builder.build());


    }

    public void notifcationchannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel nc = new NotificationChannel(channelname,
                    notifname, NotificationManager.IMPORTANCE_HIGH);
            nc.setDescription("Rating Notification");
            nc.enableVibration(true);
            nm.createNotificationChannel(nc);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    nm.cancel(notifid);
    }
}

package com.ofa.ratenoti;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        float f=intent.getFloatExtra("rating",0.0f);
        Toast.makeText(context, "Your rating is "+f, Toast.LENGTH_SHORT).show();
    }
}
